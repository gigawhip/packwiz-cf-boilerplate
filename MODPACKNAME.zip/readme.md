# MODPACKNAME Local Development MMC Pack

## Usage

- In an MMC fork, create a new instance and import from zip
- When you run the pack, it expects a local packwiz project to be running `packwiz serve`

## Exporting

To re-export this pack cleanly:

- `cd` to the MMC instance folder where this readme file resides
- Edit the `.gitignore` to whitelist any files in `.minecraft` that you want to keep
- `git init` then `git clean -Xdf` to delete all gitignored files.
  - Note: you can delete the `.git` folder after this if you want. We're only using `git` to use `git clean` as a cross-platform way to remove undesirable files. unfortunately, `.packignore` isn't smart enough to be sufficient.
- In MMC, select the instance and choose "Export instance". The `.git` folder should be unchecked, and the rest of the files should be checked. Click "OK" then choose where to save the file.
